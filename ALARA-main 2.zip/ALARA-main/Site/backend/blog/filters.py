import django_filters
from .models import Post


class PostFilter(django_filters.FilterSet):
    tags = django_filters.CharFilter(field_name='tags__name', lookup_expr='icontains')
    published_after = django_filters.DateFilter(field_name='published_at', lookup_expr='gte')
    published_before = django_filters.DateFilter(field_name='published_at', lookup_expr='lte')

    class Meta:
        model = Post
        fields = ['tags', 'published_after', 'published_before']
