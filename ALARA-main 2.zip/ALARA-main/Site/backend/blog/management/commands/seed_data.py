from django.core.management.base import BaseCommand
from blog.models import Post, Tag
from django.utils import timezone


class Command(BaseCommand):
    help = 'Seed the database with sample blog posts'

    def handle(self, *args, **options):
        # Create tags
        tags_data = [
            'Anksiyete',
            'Depresyon',
            'Aile Terapisi',
            'Çocuk Psikolojisi',
            'Stres Yönetimi',
            'Kişisel Gelişim'
        ]
        
        tags = []
        for tag_name in tags_data:
            tag, created = Tag.objects.get_or_create(
                name=tag_name,
                defaults={'slug': tag_name.lower().replace(' ', '-')}
            )
            tags.append(tag)
            if created:
                self.stdout.write(f'Created tag: {tag_name}')

        # Create sample posts
        posts_data = [
            {
                'title': 'Anksiyete ile Başa Çıkma Yöntemleri',
                'slug': 'anksiyete-ile-basa-cikma-yontemleri',
                'excerpt': 'Anksiyete bozukluğu yaşayan bireyler için etkili başa çıkma stratejileri ve profesyonel destek süreçleri.',
                'content': '''# Anksiyete ile Başa Çıkma Yöntemleri

Anksiyete, günümüzde birçok insanın karşılaştığı yaygın bir ruh sağlığı sorunudur. Bu yazıda, anksiyete ile etkili bir şekilde başa çıkmanın yollarını ele alacağız.

## Nefes Egzersizleri

Derin nefes alma teknikleri anksiyete anında sakinleşmenize yardımcı olabilir:

- **4-7-8 Tekniği**: 4 saniye nefes alın, 7 saniye tutun, 8 saniyede verin
- **Diyafram Nefesi**: Karından nefes alarak vücudunuzu rahatlatın

## Mindfulness ve Meditasyon

Günlük meditasyon pratiği anksiyete seviyelerini önemli ölçüde azaltabilir:

- Her gün 10-15 dakika meditasyon yapın
- Şimdiki ana odaklanın
- Düşüncelerinizi yargılamadan gözlemleyin

## Profesyonel Destek

Anksiyete belirtileri şiddetli olduğunda mutlaka bir uzmandan destek alın. Terapi süreci size özel stratejiler geliştirmenize yardımcı olacaktır.

Unutmayın, anksiyete ile başa çıkmak bir süreçtir ve sabır gerektirir.''',
                'tags': ['Anksiyete', 'Stres Yönetimi', 'Kişisel Gelişim']
            },
            {
                'title': 'Çocuklarda Duygusal Zeka Gelişimi',
                'slug': 'cocuklarda-duygusal-zeka-gelisimi',
                'excerpt': 'Çocukların duygusal zeka becerilerini geliştirmek için ebeveynlere pratik öneriler ve aktiviteler.',
                'content': '''# Çocuklarda Duygusal Zeka Gelişimi

Duygusal zeka, çocukların gelecekteki başarısı ve mutluluğu için kritik öneme sahiptir. Bu yazıda çocuklarınızın duygusal zeka becerilerini nasıl geliştirebileceğinizi öğreneceksiniz.

## Duygusal Zeka Nedir?

Duygusal zeka şu temel becerileri içerir:

- **Duyguları Tanıma**: Kendi ve başkalarının duygularını anlama
- **Duyguları Yönetme**: Duyguları uygun şekilde ifade etme
- **Empati**: Başkalarının duygularını anlama
- **Sosyal Beceriler**: İlişkileri yönetme

## Geliştirme Stratejileri

### 1. Duygu Sözlüğü Oluşturun
Çocuğunuzla birlikte farklı duyguları tanımlayın ve isimlendirin.

### 2. Duygusal Hikayeler Okuyun
Duyguları konu alan kitaplar okuyarak çocuğunuzun duygusal farkındalığını artırın.

### 3. Model Olun
Çocuklar ebeveynlerini taklit eder. Kendi duygularınızı sağlıklı şekilde ifade edin.

## Yaş Gruplarına Göre Aktiviteler

**2-4 Yaş**: Temel duyguları tanıma oyunları
**5-8 Yaş**: Duygusal hikaye anlatma
**9-12 Yaş**: Empati geliştirme aktiviteleri

Duygusal zeka gelişimi sabır ve tutarlılık gerektirir. Çocuğunuzun kendi hızında ilerlemesine izin verin.''',
                'tags': ['Çocuk Psikolojisi', 'Aile Terapisi', 'Kişisel Gelişim']
            },
            {
                'title': 'Depresyon Tedavisinde Bilişsel Davranışçı Terapi',
                'slug': 'depresyon-tedavisinde-bilisel-davranisci-terapi',
                'excerpt': 'Depresyon tedavisinde BDT\'nin etkinliği, terapi süreci ve hastaların beklediği sonuçlar hakkında kapsamlı bilgi.',
                'content': '''# Depresyon Tedavisinde Bilişsel Davranışçı Terapi

Bilişsel Davranışçı Terapi (BDT), depresyon tedavisinde en etkili yöntemlerden biridir. Bu yazıda BDT'nin depresyon tedavisindeki rolünü detaylı olarak inceleyeceğiz.

## BDT Nedir?

BDT, düşünce, duygu ve davranış arasındaki bağlantıları inceleyen kanıta dayalı bir terapi yöntemidir.

## Depresyondaki Temel BDT Teknikleri

### 1. Düşünce Kayıtları
Olumsuz düşünceleri tanımlama ve analiz etme:

- **Otomatik Düşünceler**: Anlık olumsuz düşünceler
- **Temel İnançlar**: Derinlerde yatan olumsuz inançlar
- **Ara İnançlar**: Düşünce kalıpları

### 2. Davranışsal Aktivasyon
Depresyonda azalan aktiviteleri artırma:

- **Keyif Verici Aktiviteler**: Haftalık aktivite planlaması
- **Sosyal Etkileşim**: İzolasyonu kırma
- **Fiziksel Aktivite**: Egzersizin ruh hali üzerindeki etkisi

### 3. Problem Çözme Becerileri
Yaşam sorunlarıyla başa çıkma stratejileri:

- **Problem Tanımlama**: Sorunları netleştirme
- **Çözüm Üretme**: Alternatif çözümler bulma
- **Uygulama**: Çözümleri hayata geçirme

## Terapi Süreci

### İlk Seanslar (1-4)
- Terapi ilişkisi kurma
- Depresyon belirtilerini değerlendirme
- Tedavi planı oluşturma

### Orta Seanslar (5-12)
- Temel BDT tekniklerini öğretme
- Ev ödevleri verme
- İlerlemeyi takip etme

### Son Seanslar (13-16)
- Öğrenilen becerileri pekiştirme
- Nüks önleme stratejileri
- Terapi sonrası planlama

## Beklenen Sonuçlar

BDT ile depresyon tedavisinde:

- %60-80 oranında iyileşme görülür
- 6-12 hafta içinde belirgin düzelme
- Uzun vadeli iyileşme oranları yüksek

## Kimler İçin Uygun?

BDT özellikle şu durumlarda etkilidir:

- Hafif-orta şiddette depresyon
- Bilişsel belirtilerin ön planda olduğu durumlar
- Aktif katılım isteyen hastalar
- Ev ödevlerini yapabilen bireyler

BDT, depresyon tedavisinde güçlü bir araçtır, ancak her hasta için uygun olmayabilir. Profesyonel değerlendirme önemlidir.''',
                'tags': ['Depresyon', 'Kişisel Gelişim']
            }
        ]

        for post_data in posts_data:
            post, created = Post.objects.get_or_create(
                slug=post_data['slug'],
                defaults={
                    'title': post_data['title'],
                    'excerpt': post_data['excerpt'],
                    'content': post_data['content'],
                    'is_published': True,
                    'published_at': timezone.now()
                }
            )
            
            if created:
                # Add tags to the post
                for tag_name in post_data['tags']:
                    tag = Tag.objects.get(name=tag_name)
                    post.tags.add(tag)
                
                self.stdout.write(f'Created post: {post.title}')
            else:
                self.stdout.write(f'Post already exists: {post.title}')

        self.stdout.write(
            self.style.SUCCESS('Successfully seeded database with sample data')
        )
