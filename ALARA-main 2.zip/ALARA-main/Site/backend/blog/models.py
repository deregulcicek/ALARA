from django.db import models
from django.utils import timezone
from django.utils.text import slugify
from django.urls import reverse
import markdown
import bleach


class Tag(models.Model):
    name = models.CharField(max_length=50, unique=True)
    slug = models.SlugField(max_length=50, unique=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['name']

    def __str__(self):
        return self.name

    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = slugify(self.name)
        super().save(*args, **kwargs)


class Post(models.Model):
    title = models.CharField(max_length=200)
    slug = models.SlugField(max_length=200, unique=True)
    cover_image = models.ImageField(upload_to='blog/covers/', blank=True, null=True)
    excerpt = models.TextField(max_length=500, blank=True)
    content = models.TextField()
    content_html = models.TextField(blank=True)
    tags = models.ManyToManyField(Tag, blank=True)
    published_at = models.DateTimeField(default=timezone.now)
    is_published = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-published_at']

    def __str__(self):
        return self.title

    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = slugify(self.title)
        
        # Convert markdown to HTML
        if self.content:
            # Convert markdown to HTML
            html = markdown.markdown(self.content, extensions=['codehilite', 'fenced_code'])
            # Sanitize HTML
            allowed_tags = ['p', 'br', 'strong', 'em', 'u', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6',
                          'ul', 'ol', 'li', 'blockquote', 'code', 'pre', 'a', 'img']
            allowed_attributes = {
                'a': ['href', 'title'],
                'img': ['src', 'alt', 'title', 'width', 'height'],
            }
            self.content_html = bleach.clean(html, tags=allowed_tags, attributes=allowed_attributes)
        
        super().save(*args, **kwargs)

    def get_absolute_url(self):
        return reverse('post-detail', kwargs={'slug': self.slug})

    @property
    def reading_time(self):
        """Estimate reading time in minutes"""
        words_per_minute = 200
        word_count = len(self.content.split())
        return max(1, round(word_count / words_per_minute))
