from django.urls import path
from . import views

urlpatterns = [
    path('', views.BlogRSSFeed(), name='rss-feed'),
]
