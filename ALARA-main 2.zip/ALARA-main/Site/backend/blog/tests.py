from django.test import TestCase
from django.urls import reverse
from rest_framework.test import APITestCase
from rest_framework import status
from django.contrib.auth.models import User
from .models import Post, Tag


class PostModelTest(TestCase):
    def setUp(self):
        self.tag = Tag.objects.create(name='Test Tag', slug='test-tag')
        self.post = Post.objects.create(
            title='Test Post',
            slug='test-post',
            content='Test content',
            excerpt='Test excerpt',
            is_published=True
        )
        self.post.tags.add(self.tag)

    def test_post_creation(self):
        self.assertEqual(self.post.title, 'Test Post')
        self.assertEqual(self.post.slug, 'test-post')
        self.assertTrue(self.post.is_published)

    def test_post_str(self):
        self.assertEqual(str(self.post), 'Test Post')

    def test_reading_time(self):
        self.assertGreater(self.post.reading_time, 0)


class PostAPITest(APITestCase):
    def setUp(self):
        self.tag = Tag.objects.create(name='Test Tag', slug='test-tag')
        self.post = Post.objects.create(
            title='Test Post',
            slug='test-post',
            content='Test content',
            excerpt='Test excerpt',
            is_published=True
        )
        self.post.tags.add(self.tag)

    def test_post_list(self):
        url = reverse('post-list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data['results']), 1)

    def test_post_detail(self):
        url = reverse('post-detail', kwargs={'slug': 'test-post'})
        response = self.client.get(url)
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['title'], 'Test Post')

    def test_post_not_found(self):
        url = reverse('post-detail', kwargs={'slug': 'non-existent'})
        response = self.client.get(url)
        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)
