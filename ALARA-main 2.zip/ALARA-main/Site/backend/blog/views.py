from django.db.models import Q
from django.core.paginator import Paginator
from django.http import HttpResponse
from django.contrib.sitemaps import Sitemap
from django.contrib.syndication.views import Feed
from rest_framework import generics, status
from rest_framework.response import Response
from rest_framework.decorators import api_view
from rest_framework.permissions import AllowAny
from .models import Post, Tag
from .serializers import PostListSerializer, PostDetailSerializer, TagSerializer
from .filters import PostFilter


class PostListView(generics.ListAPIView):
    """List all published blog posts with pagination and search"""
    serializer_class = PostListSerializer
    permission_classes = [AllowAny]
    filterset_class = PostFilter
    
    def get_queryset(self):
        return Post.objects.filter(is_published=True).select_related().prefetch_related('tags')


class PostDetailView(generics.RetrieveAPIView):
    """Retrieve a single blog post by slug"""
    serializer_class = PostDetailSerializer
    permission_classes = [AllowAny]
    lookup_field = 'slug'
    
    def get_queryset(self):
        return Post.objects.filter(is_published=True).select_related().prefetch_related('tags')


class TagListView(generics.ListAPIView):
    """List all tags"""
    serializer_class = TagSerializer
    permission_classes = [AllowAny]
    queryset = Tag.objects.all()


@api_view(['GET'])
def post_search(request):
    """Search posts by title and content"""
    query = request.GET.get('q', '')
    if not query:
        return Response({'posts': []})
    
    posts = Post.objects.filter(
        Q(is_published=True) & 
        (Q(title__icontains=query) | Q(content__icontains=query) | Q(excerpt__icontains=query))
    ).select_related().prefetch_related('tags')
    
    serializer = PostListSerializer(posts, many=True)
    return Response({'posts': serializer.data})


class BlogSitemap(Sitemap):
    """Sitemap for blog posts"""
    changefreq = "weekly"
    priority = 0.8

    def items(self):
        return Post.objects.filter(is_published=True)

    def lastmod(self, obj):
        return obj.updated_at


def sitemap(request):
    """Generate sitemap.xml"""
    from django.contrib.sitemaps import Sitemap
    from django.http import HttpResponse
    from django.template.loader import render_to_string
    
    sitemap = BlogSitemap()
    context = {
        'sitemap': sitemap,
        'site': request.get_host(),
    }
    
    xml = render_to_string('sitemap.xml', context)
    return HttpResponse(xml, content_type='application/xml')


class BlogRSSFeed(Feed):
    """RSS feed for blog posts"""
    title = "Psikolog Alara Okul - Blog"
    link = "/rss.xml"
    description = "Psikolog Alara Okul'un blog yazıları"

    def items(self):
        return Post.objects.filter(is_published=True).order_by('-published_at')[:20]

    def item_title(self, item):
        return item.title

    def item_description(self, item):
        return item.excerpt

    def item_link(self, item):
        return f"/blog/{item.slug}/"

    def item_pubdate(self, item):
        return item.published_at