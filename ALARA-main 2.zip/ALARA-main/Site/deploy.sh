#!/bin/bash

# Production Deploy Script for Psikolog Alara Okul Website
# Usage: ./deploy.sh [domain]

set -e

DOMAIN=${1:-okulpsikoloji.com.tr}
echo "🚀 Deploying to domain: $DOMAIN"

# Check if .env file exists
if [ ! -f ".env" ]; then
    echo "❌ .env file not found. Please copy env.production to .env and configure it."
    exit 1
fi

# Check if domain is configured
if ! grep -q "DOMAIN=$DOMAIN" .env; then
    echo "❌ Domain $DOMAIN not configured in .env file"
    exit 1
fi

echo "📦 Building frontend..."
cd frontend
npm run build
cd ..

echo "📦 Building backend..."
docker-compose -f docker-compose.prod.yml build

echo "🔄 Stopping existing services..."
docker-compose -f docker-compose.prod.yml down

echo "🚀 Starting production services..."
docker-compose -f docker-compose.prod.yml up -d

echo "⏳ Waiting for services to start..."
sleep 30

echo "🗄️ Running database migrations..."
docker-compose -f docker-compose.prod.yml exec web python manage.py migrate

echo "📊 Collecting static files..."
docker-compose -f docker-compose.prod.yml exec web python manage.py collectstatic --noinput

echo "🌱 Seeding initial data..."
docker-compose -f docker-compose.prod.yml exec web python manage.py seed_data

echo "✅ Deploy completed successfully!"
echo "🌐 Your website is now available at: https://$DOMAIN"
echo "🔧 Admin panel: https://$DOMAIN/admin"
echo "📊 API docs: https://$DOMAIN/api/docs"

echo ""
echo "📋 Next steps:"
echo "1. Create a superuser: docker-compose -f docker-compose.prod.yml exec web python manage.py createsuperuser"
echo "2. Check logs: docker-compose -f docker-compose.prod.yml logs -f"
echo "3. Monitor the site: https://$DOMAIN"
